<?php

$PHPstatement = <<<EOT
if (1) {
//expression;
}
EOT;

$validPHPstatement = '/^([a-z]+\s?\(.+\)\s?\{)[\n]*(.+)[\n]*\}$/';

$result = preg_match($validPHPstatement, $PHPstatement, $matches);

var_dump($matches);